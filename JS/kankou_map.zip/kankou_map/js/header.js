const header = document.querySelector("header");

let previousScroll = 0;  // 前回のスクロール量
let scrolled = 0;  // 現在のスクロール量

window.addEventListener("scroll", ()=>{
  previousScroll = scrolled;
  scrolled = window.pageYOffset
  
  if(scrolled > previousScroll){  // スクロールした時
    header.style = "position: absolute; top: -100%"; // headerを画面外へ非表示
  }else{  // バックスクロールした時
    header.style = "position: fixed; top: 0"; // headerを再表示
  }
});