/* headerのimport */
import Header from '../components/header';

const TopPage = () => {
  return (
    <div>
        <Header />
    </div>
  );
};

export default TopPage;