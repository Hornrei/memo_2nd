/* ページのヘッダーを作るコンポーネント */

const Header = () => {
    return (
        <header>
        <h1>月齢カレンダー</h1>
        </header>
    );
    };

export default Header;