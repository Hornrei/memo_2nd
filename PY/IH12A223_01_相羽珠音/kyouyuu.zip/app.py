from flask import Flask, render_template, request, redirect, session, jsonify
import mysql.connector
import hashlib

app = Flask(__name__)
app.secret_key = "ebtih12a3b4c5d6e7f8g9h0i"
app.json.ensure_ascii = False


def database_connection():
    return mysql.connector.connect(
        user='root',
        # password='',
        password='root',
        host='localhost',
        # port='3306',
        database='py',
    )


def authentification(email, password):

    password = hashlib.sha256(password.encode()).hexdigest()

    try:
        # データベース接続
        cnx = database_connection()
        if cnx is not None and cnx.is_connected:
            cur = cnx.cursor()
            # SQL文
            sql = "SELECT * FROM users WHERE email = %s AND password = %s"
            cur.execute(sql, (email, password))
            # データ取得
            user = cur.fetchone()
            # データベース切断
            cur.close()
            cnx.close()

            session["user"] = user
            session["signin"] = True
            return True
        else:
            return False
    except Exception as e:
        return False


@app.route("/")
def index():
    signin = session.get("signin", False)
    return render_template("index.html", signin=signin)


@app.route("/signin", methods=["GET"])
def signin():

    if "signin" in session and session["signin"]:
        return redirect("/")

    return render_template("signin.html")


@app.route("/signin", methods=["POST"])
def signin_post():
    # signin処理
    email = request.form.get("email")
    password = request.form.get("password")

    if email is None or password is None:
        return redirect("/signin")

    if authentification(email, password):
        return redirect("/")
    else:
        return redirect("/signin")


@app.route("/signout")
def signout():
    # signout処理
    session.pop("user", None)
    session.pop("signin", None)
    return redirect("/")

# 新規ユーザー登録


@app.route("/signup", methods=["GET"])
def signup():
    return render_template("signup.html")


@app.route("/signup", methods=["POST"])
def signup_post():
    email = request.form.get("email")
    password = request.form.get("password")
    username = request.form.get("username")

    if email is None or password is None or username is None:
        return redirect("/signup")

    password = hashlib.sha256(password.encode()).hexdigest()

    try:
        cnx = database_connection()
        if cnx is not None and cnx.is_connected:
            cur = cnx.cursor()
            sql = "INSERT INTO users (email, password, username) VALUES (%s, %s, %s)"
            cur.execute(sql, (email, password, username))
            cnx.commit()
            cur.close()
            cnx.close()
            return redirect("/signin")
        else:
            return redirect("/signup")
    except Exception as e:
        print(e)
        return redirect("/signup")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/get_json")
def get_json():
    return jsonify({
        "news": [
            {
                "title": "PYの評価課題が発表されました",
                "body": "あああああああああああああああああ"
            },
            {
                "title": "PYの評価課題が発表されました2",
                "body": "あああああああああああああああああ"
            },
        ],
    })


if __name__ == "__main__":
    app.run(debug=True, host="localhost", port=5000)
